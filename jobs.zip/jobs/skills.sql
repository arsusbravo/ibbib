-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.4.10-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Structuur van  tabel jobs.skills wordt geschreven
CREATE TABLE IF NOT EXISTS `skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language_skill_id` int(11) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_skills_language_skills` (`language_skill_id`),
  CONSTRAINT `FK_skills_language_skills` FOREIGN KEY (`language_skill_id`) REFERENCES `language_skills` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

-- Dumpen data van tabel jobs.skills: ~11 rows (ongeveer)
/*!40000 ALTER TABLE `skills` DISABLE KEYS */;
INSERT INTO `skills` (`id`, `language_skill_id`, `description`, `created_at`, `updated_at`) VALUES
	(1, 1, NULL, '2020-02-01 21:33:22', '2020-02-01 21:33:23'),
	(3, 2, NULL, '2020-02-01 21:33:45', '2020-02-01 21:33:45'),
	(4, 3, NULL, '2020-02-01 21:33:59', '2020-02-01 21:34:00'),
	(5, 4, NULL, '2020-02-01 21:34:08', '2020-02-01 21:34:09'),
	(6, 5, NULL, '2020-02-01 21:34:18', '2020-02-01 21:34:19'),
	(7, 6, NULL, '2020-02-01 21:34:31', '2020-02-01 21:34:31'),
	(8, 7, NULL, '2020-02-01 21:34:40', '2020-02-01 21:34:41'),
	(9, 8, NULL, '2020-02-01 21:34:49', '2020-02-01 21:34:49'),
	(10, 9, NULL, '2020-02-01 21:34:58', '2020-02-01 21:34:58'),
	(11, 11, NULL, '2020-02-01 21:35:04', '2020-02-01 21:35:04'),
	(12, 13, NULL, '2020-02-10 21:04:06', '2020-02-10 21:04:06');
/*!40000 ALTER TABLE `skills` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
