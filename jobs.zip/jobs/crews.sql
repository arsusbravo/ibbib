-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.4.10-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Structuur van  tabel jobs.crews wordt geschreven
CREATE TABLE IF NOT EXISTS `crews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `co_name` varchar(50) DEFAULT NULL,
  `co_phone` varchar(50) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `newsletter` tinyint(4) DEFAULT NULL COMMENT 'ja of nee',
  `objective` varchar(100) DEFAULT NULL COMMENT 'titel',
  `resume` mediumtext DEFAULT NULL COMMENT 'motivatie brief',
  `additional_info` mediumtext DEFAULT NULL COMMENT 'andere info',
  `standard_rates` decimal(10,2) DEFAULT NULL COMMENT 'standaard tarief',
  `unit_rate` varchar(50) DEFAULT NULL COMMENT 'per uur of woord',
  `credits` int(11) DEFAULT NULL COMMENT 'betalen voor 1 krediet',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_crews_users` (`user_id`),
  KEY `FK_crews_countries` (`country_id`),
  CONSTRAINT `FK_crews_countries` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `FK_crews_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumpen data van tabel jobs.crews: ~1 rows (ongeveer)
/*!40000 ALTER TABLE `crews` DISABLE KEYS */;
INSERT INTO `crews` (`id`, `user_id`, `co_name`, `co_phone`, `country_id`, `newsletter`, `objective`, `resume`, `additional_info`, `standard_rates`, `unit_rate`, `credits`, `created_at`, `updated_at`) VALUES
	(1, 2, 'ARSUS Translator', NULL, 156, NULL, NULL, NULL, NULL, 0.50, 'word', NULL, '2020-02-01 22:33:21', '2020-02-01 22:33:21');
/*!40000 ALTER TABLE `crews` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
