-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.4.10-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Structuur van  tabel jobs.projects wordt geschreven
CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `crew_id` int(11) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `skill_id` int(11) DEFAULT NULL,
  `content` mediumtext DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `published` tinyint(4) DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_projects_crews` (`crew_id`),
  KEY `FK_projects_customers` (`customer_id`),
  CONSTRAINT `FK_projects_crews` FOREIGN KEY (`crew_id`) REFERENCES `crews` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `FK_projects_customers` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- Dumpen data van tabel jobs.projects: ~1 rows (ongeveer)
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` (`id`, `customer_id`, `crew_id`, `title`, `slug`, `skill_id`, `content`, `deleted`, `published`, `published_at`, `deadline`, `created_at`, `updated_at`) VALUES
	(1, 2, NULL, 'Test project', 'test-project', 12, 'test Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris at nibh sit amet ex aliquam congue eget at turpis. Maecenas non auctor diam. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer tincidunt sapien nibh, eget porttitor metus convallis venenatis. Sed mollis ligula sed imperdiet maximus. Suspendisse vestibulum sagittis dolor, eget sollicitudin leo porttitor ac. Interdum et malesuada fames ac ante ipsum primis in faucibus. Suspendisse potenti. Mauris nec purus aliquam, mattis mauris nec, tempus dui. Pellentesque aliquam orci ac ante elementum blandit. Phasellus tristique fermentum enim, at posuere leo dignissim id. Integer aliquet elit vitae neque interdum tempus.\r\n\r\nInterdum et malesuada fames ac ante ipsum primis in faucibus. Integer pharetra ornare quam in volutpat. Vestibulum nec vulputate quam, et mattis tellus. Vivamus posuere vel massa nec ornare. Sed hendrerit, ex in venenatis vulputate, ante enim ultrices ante, sit amet consectetur sem elit accumsan tortor. Praesent ut pulvinar turpis. Morbi auctor auctor velit sed hendrerit. Proin vehicula sagittis vestibulum. Vivamus ante risus, hendrerit eget ex eget, lacinia imperdiet ante.', NULL, 1, '2020-02-09 00:00:00', '2020-03-31', '2020-02-09 19:27:45', '2020-02-10 21:12:56');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
