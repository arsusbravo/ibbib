-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.4.10-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Structuur van  tabel jobs.users wordt geschreven
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `active` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `FK_users_roles` (`role_id`),
  CONSTRAINT `FK_users_roles` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumpen data van tabel jobs.users: ~3 rows (ongeveer)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `role_id`, `email_verified_at`, `password`, `remember_token`, `active`, `created_at`, `updated_at`) VALUES
	(1, 'Ario Susmaryono', 'info@arsus.nl', 1, NULL, '$2y$10$2.07TRwAfWbmLvAKmYq7X.taoH8r.7ODOX9gkQGx9lh2ptiGf9Rvy', 'AYgurkZLwGJLY01kwVxupjXCQ6LhqpVq3GWZslO570jGH1UuOCI7UwbhJ1q4', 1, '2020-01-25 15:37:06', '2020-01-25 15:37:06'),
	(2, 'First translator', 'ario_susmaryono@hotmail.com', 4, NULL, '$2y$10$TqQMCLkbHWK42s86XMTWV.xpIgHAzshsl/d1oWHbZLlYl0fn52Yv6', 'TROQQyS8w2CalTD7WArwpzHVyPJAnpqRBCTPK8rPvAqAetenMvTKBsFWnvg8', 1, '2020-01-25 22:12:52', '2020-01-25 22:12:52'),
	(3, 'Ontwikkelaar Test', 'ario@hypotheekonline.nl', 3, NULL, '$2y$10$GyE1ihmLruZhDTv/a07IU.t9Ci8/zQbL86Ab63onCBeYlgdTUfG/G', NULL, 1, '2020-02-05 20:21:43', '2020-02-05 20:21:43');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
