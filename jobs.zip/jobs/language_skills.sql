-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.4.10-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Structuur van  tabel jobs.language_skills wordt geschreven
CREATE TABLE IF NOT EXISTS `language_skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` int(11) DEFAULT NULL,
  `to` int(11) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_language_skills_languages` (`from`),
  KEY `FK_language_skills_languages_2` (`to`),
  CONSTRAINT `FK_language_skills_languages` FOREIGN KEY (`from`) REFERENCES `languages` (`id`),
  CONSTRAINT `FK_language_skills_languages_2` FOREIGN KEY (`to`) REFERENCES `languages` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

-- Dumpen data van tabel jobs.language_skills: ~11 rows (ongeveer)
/*!40000 ALTER TABLE `language_skills` DISABLE KEYS */;
INSERT INTO `language_skills` (`id`, `from`, `to`, `description`, `created_at`, `updated_at`) VALUES
	(1, 1, 2, NULL, '2020-02-01 21:30:05', '2020-02-01 21:30:05'),
	(2, 1, 3, NULL, '2020-02-01 21:30:22', '2020-02-01 21:30:22'),
	(3, 1, 4, NULL, '2020-02-01 21:30:36', '2020-02-01 21:30:37'),
	(4, 1, 5, NULL, '2020-02-01 21:30:48', '2020-02-01 21:30:48'),
	(5, 2, 1, NULL, '2020-02-01 21:30:59', '2020-02-01 21:30:59'),
	(6, 2, 3, NULL, '2020-02-01 21:31:08', '2020-02-01 21:31:08'),
	(7, 2, 4, NULL, '2020-02-01 21:31:29', '2020-02-01 21:31:29'),
	(8, 2, 5, NULL, '2020-02-01 21:32:22', '2020-02-01 21:32:22'),
	(9, 3, 1, NULL, '2020-02-01 21:32:24', '2020-02-01 21:32:24'),
	(11, 3, 4, NULL, '2020-02-01 21:32:38', '2020-02-01 21:32:38'),
	(13, 3, 2, NULL, '2020-02-10 21:04:06', '2020-02-10 21:04:06');
/*!40000 ALTER TABLE `language_skills` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
