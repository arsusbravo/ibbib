-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.4.10-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Structuur van  tabel jobs.crews_skills wordt geschreven
CREATE TABLE IF NOT EXISTS `crews_skills` (
  `crew_id` int(11) DEFAULT NULL,
  `skill_id` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  KEY `FK_crews_skills_crews` (`crew_id`),
  KEY `FK_crews_skills_skills` (`skill_id`),
  CONSTRAINT `FK_crews_skills_crews` FOREIGN KEY (`crew_id`) REFERENCES `crews` (`id`),
  CONSTRAINT `FK_crews_skills_skills` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumpen data van tabel jobs.crews_skills: ~1 rows (ongeveer)
/*!40000 ALTER TABLE `crews_skills` DISABLE KEYS */;
INSERT INTO `crews_skills` (`crew_id`, `skill_id`, `level`) VALUES
	(1, 1, 3);
/*!40000 ALTER TABLE `crews_skills` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
