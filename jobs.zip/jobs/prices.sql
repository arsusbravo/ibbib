-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.4.10-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Structuur van  tabel jobs.prices wordt geschreven
CREATE TABLE IF NOT EXISTS `prices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_prices_roles` (`role_id`),
  CONSTRAINT `FK_prices_roles` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- Dumpen data van tabel jobs.prices: ~5 rows (ongeveer)
/*!40000 ALTER TABLE `prices` DISABLE KEYS */;
INSERT INTO `prices` (`id`, `role_id`, `title`, `slug`, `description`, `price`, `quantity`, `unit`, `created_at`, `updated_at`) VALUES
	(1, 4, 'One Reaction', 'crew-1-credit', NULL, NULL, 1, 'credit', '2020-02-09 11:51:33', '2020-02-09 11:51:34'),
	(2, 4, '25 Reactions', 'crew-25-credits', NULL, NULL, 25, 'credit', '2020-02-09 11:53:08', '2020-02-09 11:53:08'),
	(3, 4, '100 Reactions', 'crew-100-credits', NULL, NULL, 100, 'credit', '2020-02-09 11:53:09', '2020-02-09 11:53:09'),
	(5, 3, 'Unlimited Translator for 30 days', 'customer-30-days', NULL, NULL, 30, 'day', '2020-02-09 12:03:37', '2020-02-09 12:03:38'),
	(6, 3, 'Unlimited Translator for A year', 'customer-365-days', NULL, NULL, 365, 'day', '2020-02-09 12:04:34', '2020-02-09 12:04:34');
/*!40000 ALTER TABLE `prices` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
