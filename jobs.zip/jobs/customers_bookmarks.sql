-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.4.10-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Structuur van  tabel jobs.customers_bookmarks wordt geschreven
CREATE TABLE IF NOT EXISTS `customers_bookmarks` (
  `customer_id` int(11) DEFAULT NULL,
  `crew_id` int(11) DEFAULT NULL,
  KEY `FK_customers_bookmarks_customers` (`customer_id`),
  KEY `FK_customers_bookmarks_crews` (`crew_id`),
  CONSTRAINT `FK_customers_bookmarks_crews` FOREIGN KEY (`crew_id`) REFERENCES `crews` (`id`),
  CONSTRAINT `FK_customers_bookmarks_customers` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumpen data van tabel jobs.customers_bookmarks: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `customers_bookmarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers_bookmarks` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
